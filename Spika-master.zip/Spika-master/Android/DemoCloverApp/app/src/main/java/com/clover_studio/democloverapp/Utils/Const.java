package com.clover_studio.democloverapp.Utils;

/**
 * Created by ubuntu_ivo on 19.08.15..
 */
public class Const {

    public static final class GCM{
        public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
        public static final String REGISTRATION_COMPLETE = "registrationComplete";
    }

}
