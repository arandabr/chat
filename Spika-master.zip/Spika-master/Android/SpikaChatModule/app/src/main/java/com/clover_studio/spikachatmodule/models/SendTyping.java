package com.clover_studio.spikachatmodule.models;

/**
 * Created by ubuntu_ivo on 22.07.15..
 */
public class SendTyping {

    public String userID;
    public int type;
    public String roomID;
    public User user;

}
