package com.clover_studio.spikachatmodule.models;

import android.os.Parcel;
import android.os.Parcelable;

import com.clover_studio.spikachatmodule.base.BaseModel;

import org.json.JSONObject;

/**
 * Created by ubuntu_ivo on 21.07.15..
 */
public class Attributes extends BaseModel{

    public ParsedUrlData linkData;

}
