package com.clover_studio.spikachatmodule.base;


/**
 * Created by ubuntu_ivo on 21.07.15..
 */
public class BaseModel {

    public int code;

    public BaseModel() {
    }

}
