package com.clover_studio.spikachatmodule.models;

/**
 * Created by ubuntu_ivo on 22.07.15..
 */
public class EmitLogin {

    public String userID;
    public String name;
    public String avatar;
    public String roomID;

}
